# GBA – native Android

mGBA (C) core hosted in C++ (`app/src/main/cpp/gba_core.cpp`: emulation thread, GLES2 video, AAudio sound, save states) with a plain Kotlin UI (on-screen pad, gamepad support, menu). No WebView, no HTML, no network permission.

Controls and game placement copy the GrLabs HTML launcher (same positions, colors, and D-pad press animation; header with GrLabs logo, » fast-forward and ☰ menu). Menu: Resume · Save/Load state (3 slots) · Fast-forward ×4 · Reset · Open ROM. Battery saves (`.sav`) are automatic. Back button or the MENU key opens the menu.

## Build
- **GitHub:** push the folder; Actions → "Build APK" → download the `gba-emulator-debug-apk` artifact (arm64).
- **Local:** open in Android Studio (NDK 26.1 + CMake 3.22.1) and run, or `gradle assembleDebug`.

## If the first build complains
- mGBA tag not found → change `MGBA_TAG` in `cpp/CMakeLists.txt`.
- `libmgba.a` missing → find its real name under `app/.cxx/**/mgba/src/mgba_ext-build/`, update `BUILD_BYPRODUCTS` / `IMPORTED_LOCATION`.
- Red/blue swapped → `SWAP_RB 1` in `gba_core.cpp`.
