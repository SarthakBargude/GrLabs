package com.gbaport.app

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Transparent on-screen gamepad drawn over the game. Multi-touch, no assets. */
class ControlsView(ctx: Context, private val onKeys: (Int) -> Unit, private val onMenu: () -> Unit) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mask = 0
    private var dpad = PointF(); private var dpadR = 0f
    private var aC = PointF(); private var bC = PointF(); private var bR = 0f
    private val lRect = RectF(); private val rRect = RectF()
    private val startRect = RectF(); private val selRect = RectF(); private val menuRect = RectF()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val W = w.toFloat(); val H = h.toFloat()
        val portrait = H > W
        val top = if (portrait) W * 2f / 3f else 0f      // game occupies the top 3:2 area in portrait
        val rh = H - top
        val cy = top + rh * 0.5f
        dpadR = if (portrait) W * 0.20f else H * 0.26f
        dpad.set(if (portrait) W * 0.27f else W * 0.16f, cy)
        bR = dpadR * 0.42f
        aC.set(W - (if (portrait) W * 0.10f else W * 0.09f) - bR, cy - bR * 0.9f)
        bC.set(aC.x - bR * 2.5f, cy + bR * 0.9f)
        val sh = bR * 1.1f
        val sw = if (portrait) W * 0.26f else H * 0.34f
        val m = W * 0.03f; val ty = top + rh * 0.04f
        lRect.set(m, ty, m + sw, ty + sh)
        rRect.set(W - m - sw, ty, W - m, ty + sh)
        val pw = if (portrait) W * 0.20f else H * 0.26f; val ph = bR * 0.7f
        val py = H - ph * 2.2f
        val sx = if (portrait) W / 2f + pw * 0.65f else (aC.x + bC.x) / 2f
        val ex = if (portrait) W / 2f - pw * 0.65f else dpad.x
        startRect.set(sx - pw / 2, py, sx + pw / 2, py + ph)
        selRect.set(ex - pw / 2, py, ex + pw / 2, py + ph)
        val mx = W / 2f
        menuRect.set(mx - pw / 2, ty, mx + pw / 2, ty + ph * 1.2f)
    }

    private fun hit(x: Float, y: Float): Int {
        var m = 0
        val dx = x - dpad.x; val dy = y - dpad.y; val d = hypot(dx, dy)
        if (d < dpadR * 1.5f && d > dpadR * 0.2f) {
            val nx = dx / d; val ny = dy / d
            if (nx > 0.38f) m = m or Gba.bit(Gba.RIGHT)
            if (nx < -0.38f) m = m or Gba.bit(Gba.LEFT)
            if (ny > 0.38f) m = m or Gba.bit(Gba.DOWN)
            if (ny < -0.38f) m = m or Gba.bit(Gba.UP)
        }
        if (hypot(x - aC.x, y - aC.y) < bR * 1.3f) m = m or Gba.bit(Gba.A)
        if (hypot(x - bC.x, y - bC.y) < bR * 1.3f) m = m or Gba.bit(Gba.B)
        val g = bR * 0.3f
        if (inflated(lRect, g).contains(x, y)) m = m or Gba.bit(Gba.L)
        if (inflated(rRect, g).contains(x, y)) m = m or Gba.bit(Gba.R)
        if (inflated(startRect, g).contains(x, y)) m = m or Gba.bit(Gba.START)
        if (inflated(selRect, g).contains(x, y)) m = m or Gba.bit(Gba.SELECT)
        return m
    }
    private fun inflated(r: RectF, g: Float) = RectF(r.left - g, r.top - g, r.right + g, r.bottom + g)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (menuRect.contains(e.getX(i), e.getY(i))) { onMenu(); return true }
        }
        var m = 0
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                m = m or hit(e.getX(i), e.getY(i))
            }
        }
        if (m != mask) {
            if (m and mask.inv() != 0) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            mask = m; onKeys(m); invalidate()
        }
        return true
    }

    fun release() { if (mask != 0) { mask = 0; onKeys(0); invalidate() } }

    private fun on(k: Int) = mask and Gba.bit(k) != 0

    private fun shape(pressed: Boolean) {
        paint.style = Paint.Style.FILL; paint.color = Color.argb(if (pressed) 150 else 55, 255, 255, 255)
    }
    private fun outline() { paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.argb(110, 255, 255, 255) }
    private fun label(t: String, cx: Float, cy: Float, size: Float) {
        paint.style = Paint.Style.FILL; paint.color = Color.argb(200, 255, 255, 255)
        paint.textSize = size; paint.textAlign = Paint.Align.CENTER
        canvas?.drawText(t, cx, cy + size * 0.35f, paint)
    }
    private var canvas: Canvas? = null

    override fun onDraw(c: Canvas) {
        canvas = c
        // d-pad: four arms
        val a = dpadR * 0.42f
        val arms = listOf(Triple(0f, -1f, Gba.UP), Triple(0f, 1f, Gba.DOWN), Triple(-1f, 0f, Gba.LEFT), Triple(1f, 0f, Gba.RIGHT))
        for ((ox, oy, k) in arms) {
            val r = RectF(dpad.x + ox * dpadR * 0.62f - a, dpad.y + oy * dpadR * 0.62f - a,
                          dpad.x + ox * dpadR * 0.62f + a, dpad.y + oy * dpadR * 0.62f + a)
            shape(on(k)); c.drawRoundRect(r, a * 0.3f, a * 0.3f, paint)
            outline(); c.drawRoundRect(r, a * 0.3f, a * 0.3f, paint)
        }
        for ((p, k, t) in listOf(Triple(aC, Gba.A, "A"), Triple(bC, Gba.B, "B"))) {
            shape(on(k)); c.drawCircle(p.x, p.y, bR, paint)
            outline(); c.drawCircle(p.x, p.y, bR, paint)
            label(t, p.x, p.y, bR * 0.8f)
        }
        for ((r, k, t) in listOf(Triple(lRect, Gba.L, "L"), Triple(rRect, Gba.R, "R"),
                                  Triple(startRect, Gba.START, "START"), Triple(selRect, Gba.SELECT, "SELECT"),
                                  Triple(menuRect, -1, "MENU"))) {
            val pressed = k >= 0 && on(k)
            shape(pressed); c.drawRoundRect(r, r.height() / 2, r.height() / 2, paint)
            outline(); c.drawRoundRect(r, r.height() / 2, r.height() / 2, paint)
            label(t, r.centerX(), r.centerY(), min(r.height() * 0.5f, bR * 0.55f))
        }
    }
}
