package com.gbaport.app

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.abs
import kotlin.math.sin

/** Where the game picture goes. Same placement as the GrLabs HTML launcher (all sizes in dp = CSS px). */
object Geo {
    fun displayBox(w: Int, dp: Float): RectF {
        val bw = w - 32f * dp
        return RectF(16f * dp, 66f * dp, 16f * dp + bw, 66f * dp + bw * 0.75f)
    }
    fun gameRect(w: Int, h: Int, dp: Float): RectF {
        if (w >= h) return RectF(0f, 0f, w.toFloat(), h.toFloat())
        val box = displayBox(w, dp)
        val gh = box.width() * 2f / 3f                       // GBA is 3:2, centred in the 4:3 display box
        val top = box.top + (box.height() - gh) / 2f
        return RectF(box.left, top, box.right, top + gh)
    }
}

/**
 * Gamepad drawn like the GrLabs HTML launcher: same positions, colors and D-pad press animation.
 * Portrait  = control deck card at the bottom, L/R tabs on its top edge, header with brand + buttons.
 * Landscape = translucent controls floating over the game.
 */
class ControlsView(
    ctx: Context,
    private val onKeys: (Int) -> Unit,
    private val onMenu: () -> Unit,
    private val onFast: () -> Unit
) : View(ctx) {

    var fastOn = false
        set(v) { field = v; invalidate() }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = Path()
    private val crossPath = Path()                  // D-pad outline in the HTML's 124x124 SVG units
    private val logo: Bitmap? = try {
        BitmapFactory.decodeResource(resources, R.drawable.grlabs_logo, BitmapFactory.Options().apply { inScaled = false })
    } catch (e: Exception) { null }

    private var mask = 0
    private var portrait = true

    private val deck = RectF()
    private val dC = PointF()
    private var span = 0f; private var k = 1f; private var uiScale = 1f
        private val aC = PointF(); private val bC = PointF(); private var btnR = 0f
    private val lRect = RectF(); private val rRect = RectF()
    private val startRect = RectF(); private val selRect = RectF()
    private val menuRect = RectF(); private val fastRect = RectF()

    init { buildCross() }

    private fun buildCross() {
        val p = crossPath
        p.reset()
        p.moveTo(44f, 0f); p.lineTo(80f, 0f); p.quadTo(83f, 0f, 83f, 3f)
        p.lineTo(83f, 38f); p.quadTo(83f, 41f, 86f, 41f)
        p.lineTo(121f, 41f); p.quadTo(124f, 41f, 124f, 44f)
        p.lineTo(124f, 80f); p.quadTo(124f, 83f, 121f, 83f)
        p.lineTo(86f, 83f); p.quadTo(83f, 83f, 83f, 86f)
        p.lineTo(83f, 121f); p.quadTo(83f, 124f, 80f, 124f)
        p.lineTo(44f, 124f); p.quadTo(41f, 124f, 41f, 121f)
        p.lineTo(41f, 86f); p.quadTo(41f, 83f, 38f, 83f)
        p.lineTo(3f, 83f); p.quadTo(0f, 83f, 0f, 80f)
        p.lineTo(0f, 44f); p.quadTo(0f, 41f, 3f, 41f)
        p.lineTo(38f, 41f); p.quadTo(41f, 41f, 41f, 38f)
        p.lineTo(41f, 3f); p.quadTo(41f, 0f, 44f, 0f)
        p.close()
    }

    // ------------------------------------------------------------ layout (numbers measured from the HTML, in dp)
    private fun box(l: Float, t: Float, w: Float, h: Float) = RectF(l * dp, t * dp, (l + w) * dp, (t + h) * dp)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val wd = w / dp; val hd = h / dp
        portrait = h > w
        if (portrait) layoutPortrait(wd, hd) else layoutLandscape(wd, hd)
    }

    private fun layoutPortrait(wd: Float, hd: Float) {
        val m = if (wd < 380f) 8f else 12f
        val deckH = if (wd < 380f) 254f else 250f
        val top = hd - m - deckH
        deck.set(m * dp, top * dp, (wd - m) * dp, (top + deckH) * dp)

        val dcx = 0.2645f * wd
        dC.set(dcx * dp, (top + 100f) * dp)
        span = 140.4f * dp; k = span / 124f
        uiScale = 1.254f * dp

        // A/B cluster spans the D-pad's full height (A top = D-pad top, B bottom = D-pad bottom)
        // and sits as far from the right edge as the D-pad sits from the left edge.
        val r = 27f
        btnR = r * dp
        val padHalf = 70.2f
        val padTop = top + 100f - padHalf; val padBottom = top + 100f + padHalf
        val aX = wd - (dcx - padHalf) - r
        val bX = aX - 46f
        aC.set(aX * dp, (padTop + r) * dp)
        bC.set(bX * dp, (padBottom - r) * dp)

        lRect.set(box(dcx - 20f - 56f, top - 22.5f, 112f, 23f))
        rRect.set(box(wd - (dcx - 20f) - 56f, top - 22.5f, 112f, 23f))
        selRect.set(box(wd / 2f - 74f, top + 195f, 64f, 23f))
        startRect.set(box(wd / 2f + 10f, top + 195f, 64f, 23f))

        menuRect.set(box(wd - 14f - 40f, 14f, 40f, 40f))
        fastRect.set(box(wd - 14f - 40f - 8f - 40f, 14f, 40f, 40f))
    }

    private fun layoutLandscape(wd: Float, hd: Float) {
        // D-pad hugs the left edge, A/B hug the right edge by the same distance, both centred at the same height.
        val edge = 26f
        val cyDp = 0.755f * hd
        dC.set((edge + 134.1f / 2f) * dp, cyDp * dp)
        span = 134.1f * dp; k = span / 124f
        uiScale = 0.9f * dp

        val s = 0.1585f * hd
        btnR = s / 2f * dp
        val bCx = wd - edge - s / 2f                          // B on the far right (as in the launcher)
        val aCx = bCx - s - 22f                               // A to its left with a clear gap
        aC.set(aCx * dp, cyDp * dp)
        bC.set(bCx * dp, cyDp * dp)

        lRect.set(box(0.03f * wd, 10f, 58f, 30f))
        rRect.set(box(wd - 0.03f * wd - 58f, 10f, 58f, 30f))
        selRect.set(box(wd / 2f - 76f, hd - 8f - 25f, 68f, 25f))
        startRect.set(box(wd / 2f + 8f, hd - 8f - 25f, 68f, 25f))

        val right = wd - 0.03f * wd - 58f - 10f
        menuRect.set(box(right - 40f, 5f, 40f, 40f))
        fastRect.set(box(right - 40f - 8f - 40f, 5f, 40f, 40f))
    }

    // ------------------------------------------------------------ touch
    private fun inflated(r: RectF, g: Float) = RectF(r.left - g, r.top - g, r.right + g, r.bottom + g)

    private fun hit(x: Float, y: Float): Int {
        var m = 0
        val half = span / 2f
        val dx = x - dC.x; val dy = y - dC.y; val d = hypot(dx, dy)
        if (d < half * 1.45f && d > half * 0.12f) {
            val nx = dx / d; val ny = dy / d
            if (nx > 0.38f) m = m or Gba.bit(Gba.RIGHT)
            if (nx < -0.38f) m = m or Gba.bit(Gba.LEFT)
            if (ny > 0.38f) m = m or Gba.bit(Gba.DOWN)
            if (ny < -0.38f) m = m or Gba.bit(Gba.UP)
        }
        if (hypot(x - aC.x, y - aC.y) < btnR * 1.35f) m = m or Gba.bit(Gba.A)
        if (hypot(x - bC.x, y - bC.y) < btnR * 1.35f) m = m or Gba.bit(Gba.B)
        val g = 8f * dp
        if (inflated(lRect, g).contains(x, y)) m = m or Gba.bit(Gba.L)
        if (inflated(rRect, g).contains(x, y)) m = m or Gba.bit(Gba.R)
        if (inflated(startRect, g).contains(x, y)) m = m or Gba.bit(Gba.START)
        if (inflated(selRect, g).contains(x, y)) m = m or Gba.bit(Gba.SELECT)
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            val x = e.getX(i); val y = e.getY(i)
            if (menuRect.contains(x, y)) { onMenu(); return true }
            if (fastRect.contains(x, y)) { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onFast(); return true }
        }
        var m = 0
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                m = m or hit(e.getX(i), e.getY(i))
            }
        }
        if (m != mask) {
            if (m and mask.inv() != 0) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            mask = m; onKeys(m); invalidate()
        }
        return true
    }

    fun release() { if (mask != 0) { mask = 0; onKeys(0); invalidate() } }
    private fun on(key: Int) = mask and Gba.bit(key) != 0

    // ------------------------------------------------------------ drawing helpers
    private fun rgba(r: Int, g: Int, b: Int, a: Float) = Color.argb((a * 255f).toInt().coerceIn(0, 255), r, g, b)

    private fun dim(color: Int, f: Float) = Color.argb(
        Color.alpha(color),
        (Color.red(color) * f).toInt(), (Color.green(color) * f).toInt(), (Color.blue(color) * f).toInt())

    private fun fill(color: Int) { paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color }
    private fun stroke(color: Int, w: Float) {
        paint.shader = null; paint.style = Paint.Style.STROKE; paint.color = color; paint.strokeWidth = w
    }

    private fun text(c: Canvas, s: String, cx: Float, cy: Float, size: Float, color: Int,
                     ls: Float = 0f, align: Paint.Align = Paint.Align.CENTER) {
        paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color
        paint.textSize = size; paint.textAlign = align; paint.typeface = Typeface.DEFAULT_BOLD
        paint.letterSpacing = ls
        val fm = paint.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, paint)
        paint.letterSpacing = 0f
    }

    /** CSS-style linear-gradient(angle) over a rectangle. */
    private fun cssGradient(r: RectF, deg: Float, colors: IntArray, stops: FloatArray): LinearGradient {
        val a = Math.toRadians(deg.toDouble())
        val dx = sin(a).toFloat(); val dy = (-cos(a)).toFloat()
        val len = abs(r.width() * dx) + abs(r.height() * dy)
        val cx = r.centerX(); val cy = r.centerY()
        return LinearGradient(cx - dx * len / 2f, cy - dy * len / 2f, cx + dx * len / 2f, cy + dy * len / 2f,
            colors, stops, Shader.TileMode.CLAMP)
    }

    // ------------------------------------------------------------ draw
    override fun onDraw(c: Canvas) {
        if (portrait) { drawDisplayBorder(c); drawDeck(c); drawHeader(c) } else drawToolbarLandscape(c)
        drawTab(c, lRect, "L", on(Gba.L))
        drawTab(c, rRect, "R", on(Gba.R))
        drawDpad(c)
        drawKey(c, aC, "A", on(Gba.A))
        drawKey(c, bC, "B", on(Gba.B))
        drawPill(c, selRect, "SELECT", on(Gba.SELECT))
        drawPill(c, startRect, "START", on(Gba.START))
    }

    private fun drawDisplayBorder(c: Canvas) {
        val b = Geo.displayBox(width, dp)
        val rad = 16f * dp
        stroke(rgba(255, 255, 255, 0.10f), 6f * dp); c.drawRoundRect(b, rad, rad, paint)
        stroke(rgba(255, 255, 255, 0.85f), 1.5f * dp); c.drawRoundRect(b, rad, rad, paint)
    }

    private fun drawDeck(c: Canvas) {
        val rt = 8f * dp; val rb = 15f * dp
        tmp.reset()
        tmp.addRoundRect(deck, floatArrayOf(rt, rt, rt, rt, rb, rb, rb, rb), Path.Direction.CW)
        paint.style = Paint.Style.FILL
        paint.shader = cssGradient(deck, 160f,
            intArrayOf(0xFF17171D.toInt(), 0xFF0B0B0F.toInt(), 0xFF14141A.toInt()), floatArrayOf(0f, 0.52f, 1f))
        c.drawPath(tmp, paint)
        val ins = RectF(deck.left + dp, deck.top + dp, deck.right - dp, deck.bottom - dp)
        tmp.reset()
        tmp.addRoundRect(ins, floatArrayOf(rt, rt, rt, rt, rb, rb, rb, rb), Path.Direction.CW)
        stroke(0xFF454550.toInt(), 2f * dp)
        c.drawPath(tmp, paint)
    }

    private fun drawHeader(c: Canvas) {
        val cy = 34f * dp
        val lh = 22f * dp
        var x = 20f * dp
        logo?.let { bmp ->
            val lw = lh * bmp.width / bmp.height
            paint.shader = null; paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.isFilterBitmap = true
            c.drawBitmap(bmp, null, RectF(x, cy - lh / 2f, x + lw, cy + lh / 2f), paint)
            x += lw + 8f * dp
        }
        text(c, "GrLabs", x, cy, 12f * dp, Color.WHITE, 0.14f, Paint.Align.LEFT)
        topButtons(c, false)
    }

    private fun drawToolbarLandscape(c: Canvas) = topButtons(c, true)

    /** Fast-forward (») and menu (hamburger) as two rounded-square buttons. */
    private fun topButtons(c: Canvas, floating: Boolean) {
        val accent = 0xFF7AA2FF.toInt()
        val ink = if (floating) 0xFFF2F2F2.toInt() else 0xFFD6D6DE.toInt()
        val rad = 12f * dp
        val inset = 2f * dp
        for (which in 0..1) {
            val r0 = if (which == 0) fastRect else menuRect
            val r = RectF(r0.left + inset, r0.top + inset, r0.right - inset, r0.bottom - inset)
            val lit = which == 0 && fastOn
            fill(if (lit) rgba(122, 162, 255, 0.20f) else if (floating) rgba(0, 0, 0, 0.38f) else rgba(255, 255, 255, 0.07f))
            c.drawRoundRect(r, rad, rad, paint)
            stroke(if (lit) rgba(122, 162, 255, 0.70f) else rgba(255, 255, 255, if (floating) 0.28f else 0.16f), 1f * dp)
            c.drawRoundRect(r, rad, rad, paint)
        }

        // » : two chevrons
        val fc = if (fastOn) accent else ink
        stroke(fc, 2.4f * dp); paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
        val cx = fastRect.centerX(); val cy = fastRect.centerY()
        for (i in 0..1) {
            val ox = cx - 3.5f * dp + i * 7f * dp
            tmp.reset()
            tmp.moveTo(ox - 2.5f * dp, cy - 5.5f * dp); tmp.lineTo(ox + 2.5f * dp, cy); tmp.lineTo(ox - 2.5f * dp, cy + 5.5f * dp)
            c.drawPath(tmp, paint)
        }

        // hamburger: three bars
        stroke(ink, 2.2f * dp)
        val w = 16f * dp; val gap = 5.5f * dp
        for (i in -1..1) {
            val y = menuRect.centerY() + i * gap
            c.drawLine(menuRect.centerX() - w / 2f, y, menuRect.centerX() + w / 2f, y, paint)
        }
        paint.strokeCap = Paint.Cap.BUTT; paint.strokeJoin = Paint.Join.MITER
    }

    // ---- L / R shoulder tabs
    private fun drawTab(c: Canvas, r0: RectF, label: String, pressed: Boolean) {
        val oy = if (pressed) 2f * dp else 0f
        val r = RectF(r0.left, r0.top + oy, r0.right, r0.bottom + oy)
        if (portrait) {
            val rad = 8f * dp
            tmp.reset()
            tmp.addRoundRect(r, floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f), Path.Direction.CW)
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, r.top, 0f, r.bottom,
                intArrayOf(0xFF32323C.toInt(), 0xFF202027.toInt(), 0xFF17171D.toInt()), floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP)
            c.drawPath(tmp, paint)
            stroke(rgba(255, 255, 255, 0.133f), 1f * dp)
            c.drawLine(r.left + rad, r.top + dp, r.right - rad, r.top + dp, paint)
            if (pressed) { fill(rgba(0, 0, 0, 0.35f)); c.drawPath(tmp, paint) }
            text(c, label, r.centerX(), r.centerY(), 11f * dp, 0xFFC4C4D4.toInt())
        } else {
            val n = c.saveLayerAlpha(r.left - 2f, r.top - 2f, r.right + 2f, r.bottom + 2f, 230)
            val rad = 9f * dp
            fill(rgba(255, 255, 255, if (pressed) 0.35f else 0.20f)); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.40f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            text(c, label, r.centerX(), r.centerY(), 10f * dp, rgba(255, 255, 255, 0.9f))
            c.restoreToCount(n)
        }
    }

    // ---- SELECT / START capsules
    private fun drawPill(c: Canvas, r0: RectF, label: String, pressed: Boolean) {
        val oy = if (pressed) 2f * dp else 0f
        val r = RectF(r0.left, r0.top + oy, r0.right, r0.bottom + oy)
        if (portrait) {
            val rad = 3f * dp
            if (!pressed) {
                val s = RectF(r.left, r.top + 3f * dp, r.right, r.bottom + 3f * dp)
                fill(0xFF08080B.toInt()); c.drawRoundRect(s, rad, rad, paint)
            }
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, rgba(75, 75, 86, 0.92f), rgba(37, 37, 45, 0.96f), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(150, 150, 170, 0.58f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.20f), 1f * dp)
            c.drawLine(r.left + rad, r.top + 1.5f * dp, r.right - rad, r.top + 1.5f * dp, paint)
            if (pressed) { fill(rgba(0, 0, 0, 0.30f)); c.drawRoundRect(r, rad, rad, paint) }
            text(c, label, r.centerX(), r.centerY(), 7f * dp, 0xFFE2E2EB.toInt(), 0.08f)
        } else {
            val n = c.saveLayerAlpha(r.left - 2f, r.top - 2f, r.right + 2f, r.bottom + 2f, 219)
            val rad = 8f * dp
            fill(rgba(255, 255, 255, if (pressed) 0.35f else 0.20f)); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.40f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            text(c, label, r.centerX(), r.centerY(), 8f * dp, rgba(255, 255, 255, 0.9f))
            c.restoreToCount(n)
        }
    }

    // ---- round A / B keys
    private fun drawKey(c: Canvas, p: PointF, label: String, pressed: Boolean) {
        val oy = if (pressed) 2f * dp else 0f
        val cx = p.x; val cy = p.y + oy; val r = btnR
        val pad = 8f * dp
        val n = c.saveLayerAlpha(cx - r - pad, cy - r - pad, cx + r + pad, cy + r + pad + 4f * dp, 235)   // opacity .92
        if (portrait) {
            if (!pressed) {
                fill(rgba(0, 0, 0, 0.45f)); c.drawCircle(cx, cy + 3.5f * dp, r, paint)
                fill(0xFF08080B.toInt()); c.drawCircle(cx, cy + 2f * dp, r, paint)
            }
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r,
                intArrayOf(rgba(90, 92, 104, 0.88f), rgba(58, 60, 71, 0.88f), rgba(35, 36, 44, 0.88f)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, paint)
            if (pressed) { fill(rgba(0, 0, 0, 0.30f)); c.drawCircle(cx, cy, r, paint) }
            stroke(rgba(200, 205, 225, 0.35f), 1f * dp); c.drawCircle(cx, cy, r - 0.5f * dp, paint)
            text(c, label, cx, cy, 19f * dp, 0xFFF0F1FA.toInt())
        } else {
            fill(rgba(255, 255, 255, if (pressed) 0.35f else 0.20f)); c.drawCircle(cx, cy, r, paint)
            stroke(rgba(255, 255, 255, 0.40f), 1f * dp); c.drawCircle(cx, cy, r - 0.5f * dp, paint)
            text(c, label, cx, cy, 19f * dp, rgba(255, 255, 255, 0.92f))
        }
        c.restoreToCount(n)
    }

    // ---- D-pad: nothing moves, so the arrows always sit dead-centre in their arms.
    // Pressed = cross dims a little, the pressed arm lights up and its arrow turns bright.
    private fun drawDpad(c: Canvas) {
        val up = on(Gba.UP); val down = on(Gba.DOWN); val lf = on(Gba.LEFT); val rt = on(Gba.RIGHT)
        val any = up || down || lf || rt
        val half = span / 2f
        val left = dC.x - half; val top = dC.y - half

        var layer = -1
        if (!portrait) layer = c.saveLayerAlpha(left - 12f * dp, top - 12f * dp, left + span + 12f * dp, top + span + 12f * dp, 158)  // opacity .62

        val f = if (any) 0.85f else 1f
        c.save(); c.translate(left, top); c.scale(k, k)
        paint.shader = LinearGradient(0f, 0f, 124f, 124f,
            intArrayOf(dim(0xFF5A5C68.toInt(), f), dim(0xFF3A3C47.toInt(), f), dim(0xFF23242C.toInt(), f)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        paint.style = Paint.Style.FILL; c.drawPath(crossPath, paint)
        stroke(rgba(200, 205, 225, 0.35f), 1f); c.drawPath(crossPath, paint)
        if (any) {
            c.save(); c.clipPath(crossPath)
            fill(rgba(255, 255, 255, 0.16f))
            if (up) c.drawRect(41f, 0f, 83f, 42f, paint)
            if (down) c.drawRect(41f, 82f, 83f, 124f, paint)
            if (lf) c.drawRect(0f, 41f, 42f, 83f, paint)
            if (rt) c.drawRect(82f, 41f, 124f, 83f, paint)
            c.restore()
        }
        c.restore()

        val dist = span * 0.335f                                 // centre of each arm (arm spans 0..41 of 124)
        arrow(c, 0f, -1f, dist, up); arrow(c, 0f, 1f, dist, down)
        arrow(c, -1f, 0f, dist, lf); arrow(c, 1f, 0f, dist, rt)

        if (layer >= 0) c.restoreToCount(layer)
    }

    private fun arrow(c: Canvas, dx: Float, dy: Float, dist: Float, pressed: Boolean) {
        val cx = dC.x + dx * dist
        val cy = dC.y + dy * dist
        val w = 10f * uiScale; val h = 7f * uiScale
        val px = -dy; val py = dx
        tmp.reset()
        tmp.moveTo(cx + dx * h / 2f, cy + dy * h / 2f)
        tmp.lineTo(cx - dx * h / 2f + px * w / 2f, cy - dy * h / 2f + py * w / 2f)
        tmp.lineTo(cx - dx * h / 2f - px * w / 2f, cy - dy * h / 2f - py * w / 2f)
        tmp.close()
        fill(if (pressed) rgba(255, 255, 255, 0.95f) else rgba(192, 192, 208, 0.75f))
        c.drawPath(tmp, paint)
    }
}
