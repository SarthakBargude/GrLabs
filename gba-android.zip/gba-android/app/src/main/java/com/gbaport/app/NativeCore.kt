package com.gbaport.app

import android.view.Surface

/** JNI wrapper around libgbacore.so (mGBA + GLES2 + AAudio). */
class NativeCore {
    companion object { init { System.loadLibrary("gbacore") } }
    external fun nativeInit()
    external fun nativeShutdown()
    external fun nativeSurfaceCreated(surface: Surface)
    external fun nativeSurfaceDestroyed()
    external fun nativeLoadRom(path: String): Boolean
    external fun nativeSetKeys(mask: Int)
    external fun nativeSetSpeed(speed: Int)
    external fun nativeSetPaused(paused: Boolean)
    external fun nativeGetState(): ByteArray?
    external fun nativeLoadState(data: ByteArray): Boolean
    /** 240x160 ARGB pixels of the last rendered frame (for thumbnails), or null. */
    external fun nativeGetFrame(): IntArray?
}

/** mGBA key bit positions. */
object Gba {
    const val A = 0; const val B = 1; const val SELECT = 2; const val START = 3
    const val RIGHT = 4; const val LEFT = 5; const val UP = 6; const val DOWN = 7
    const val R = 8; const val L = 9
    fun bit(k: Int) = 1 shl k
}
