package com.gbaport.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Pixel font for the save-state screen. Drop a pixel TTF (e.g. Silkscreen) at app/src/main/assets/fonts/pixel.ttf
 * and it is used automatically; without it the screen falls back to bold monospace.
 */
object PixelFont {
    private var cached: Typeface? = null
    fun get(ctx: Context): Typeface {
        cached?.let { return it }
        val t = try { Typeface.createFromAsset(ctx.assets, "fonts/pixel.ttf") }
                catch (e: Exception) { Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
        cached = t
        return t
    }
}

/** One cell of the save-state grid. [time] == null means the slot is empty. */
class SlotInfo(val key: String, val title: String, val time: Long?, val thumb: Bitmap?)

private class CloseButton(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - d
        p.style = Paint.Style.FILL; p.color = 0xFF14141A.toInt(); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = 0xFF454550.toInt(); c.drawCircle(cx, cy, r, p)
        p.color = Color.WHITE; p.strokeWidth = 2.6f * d; p.strokeCap = Paint.Cap.ROUND
        val a = 7f * d
        c.drawLine(cx - a, cy - a, cx + a, cy + a, p)
        c.drawLine(cx - a, cy + a, cx + a, cy - a, p)
    }
}

/** Full-screen "SAVE STATES" grid: Quick Save (auto) + numbered slots with screenshot thumbnails. */
class StatesView(
    ctx: Context,
    private val onClose: () -> Unit,
    private val onSlot: (String) -> Unit
) : FrameLayout(ctx) {

    private val header = FrameLayout(ctx)
    private val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var slots: List<SlotInfo> = emptyList()
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0

    init {
        setBackgroundColor(0xFF08080B.toInt())
        isClickable = true

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        header.addView(TextView(ctx).apply {
            text = "SAVE STATES"; textSize = 15f; setTextColor(Color.WHITE)
            typeface = PixelFont.get(ctx); letterSpacing = 0.25f; includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.START))
        header.addView(CloseButton(ctx).apply { setOnClickListener { onClose() } },
            LayoutParams(ctx.dpi(46f), ctx.dpi(46f), Gravity.CENTER_VERTICAL or Gravity.END))
        col.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(View(ctx).apply { setBackgroundColor(0xFF22222A.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))

        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(grid) }
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding(); rebuild()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        val p = context.dpi(18f)
        header.setPadding(p + insL, context.dpi(14f) + insT, p + insR, context.dpi(14f))
        grid.setPadding(p + insL, p, p + insR, p + insB)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { rebuild() }
    }

    fun refresh(list: List<SlotInfo>) { slots = list; rebuild() }

    private fun rebuild() {
        val c = context
        grid.removeAllViews()
        val avail = width - grid.paddingLeft - grid.paddingRight
        if (avail <= 0 || slots.isEmpty()) return
        val gap = c.dpi(12f)
        val cols = maxOf(2, avail / c.dpi(210f))
        val cardW = (avail - gap * (cols - 1)) / cols

        var i = 0
        while (i < slots.size) {
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until cols) {
                val lp = LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.MATCH_PARENT)   // equal heights per row
                if (j > 0) lp.leftMargin = gap
                if (i + j < slots.size) row.addView(card(c, slots[i + j], cardW), lp)
                else row.addView(View(c), lp)
            }
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { if (i > 0) topMargin = gap })
            i += cols
        }
    }

    private fun card(c: Context, s: SlotInfo, cardW: Int): View {
        val pad = c.dpi(10f)
        val r = c.dpi(18f).toFloat()
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = pressable(shape(0xFF111116.toInt(), r, 0xFF2A2A33.toInt(), c.dpi(1f)),
                                   shape(0xFF1A1A22.toInt(), r, 0xFF3A3A46.toInt(), c.dpi(1f)))
            isClickable = true
            setOnClickListener { onSlot(s.key) }
        }
        val tw = cardW - pad * 2
        val th = tw * 2 / 3
        val radius = c.dpi(12f).toFloat()
        val thumbBox = FrameLayout(c).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, radius) }
            }
            setBackgroundColor(0xFF050507.toInt())
        }
        if (s.thumb != null) {
            val d = BitmapDrawable(c.resources, s.thumb); d.setFilterBitmap(false)
            thumbBox.addView(ImageView(c).apply { setImageDrawable(d); scaleType = ImageView.ScaleType.FIT_XY },
                FrameLayout.LayoutParams(-1, -1))
        } else {
            thumbBox.addView(TextView(c).apply {
                text = "EMPTY"; textSize = 11f; setTextColor(0xFF3A3A44.toInt())
                typeface = PixelFont.get(c); letterSpacing = 0.18f; includeFontPadding = false
            }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        card.addView(thumbBox, LinearLayout.LayoutParams(tw, th))

        val stamp = s.time?.let { java.text.SimpleDateFormat("dd/MM/yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(it)) }
        val caption = if (stamp != null) "${s.title} · $stamp" else s.title
        card.addView(TextView(c).apply {
            text = caption; textSize = 10.5f; typeface = PixelFont.get(c); letterSpacing = 0.12f
            setTextColor(if (stamp != null) 0xFFEDEDF3.toInt() else 0xFF55555F.toInt())
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END; includeFontPadding = false
            setLineSpacing(c.dpi(3f).toFloat(), 1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = c.dpi(10f) })
        return card
    }
}
