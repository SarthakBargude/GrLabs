package com.gbaport.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.view.View.MeasureSpec
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val core = NativeCore()
    private lateinit var controls: ControlsView
    private lateinit var home: HomeView
    private lateinit var states: StatesView
    private val prefs by lazy { getSharedPreferences("gba", MODE_PRIVATE) }
    private val romDir by lazy { File(filesDir, "roms").apply { mkdirs() } }
    private val stateDir by lazy { File(filesDir, "states").apply { mkdirs() } }
    private var romName: String? = null          // ROM currently loaded in the core (null = none)
    private var touchMask = 0
    private var padMask = 0
    private var fastForward = false
    private var dialogOpen = false
    private var homeOpen = true
    private var statesOpen = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        core.nativeInit()

        val surface = SurfaceView(this)
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) = core.nativeSurfaceCreated(h.surface)
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) = core.nativeSurfaceDestroyed()
        })
        controls = ControlsView(this, { m -> touchMask = m; sendKeys() }, { showMenu() }, { toggleFast() })
        home = HomeView(this, { name -> play(name) }, { pickRom() }, { name -> confirmRemove(name) })

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(GameLayout(this, surface, controls), FrameLayout.LayoutParams(-1, -1))
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        states = StatesView(this, { closeStates() }, { key -> slotTapped(key) })
        states.visibility = View.GONE
        root.addView(states, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        hideBars()
        showHome()
    }

    // ---------- Home screen ----------
    private fun listGames(): List<Game> =
        (romDir.listFiles() ?: emptyArray<File>())
            .filter { it.isFile && !it.name.endsWith(".sav", ignoreCase = true) }
            .map { Game(it.name, it.length()) }
            .sortedBy { it.name.lowercase() }

    private fun showHome() {
        if (!homeOpen) quickSave()
        controls.release(); core.nativeSetPaused(true)
        homeOpen = true
        home.refresh(listGames(), prefs.getString("rom", null), romName != null)
        home.visibility = View.VISIBLE
    }

    private fun hideHome() { homeOpen = false; home.visibility = View.GONE }

    private fun play(name: String) {
        if (name == romName) { hideHome(); resume() }     // already running: just jump back in
        else loadRom(name)
    }

    private fun confirmRemove(name: String) {
        sheet("Remove game?", prettyName(name), listOf(
            SheetItem("Remove game and its saves", style = STYLE_DANGER) { removeGame(name) },
            SheetItem("Cancel") { }
        ), resumeOnCancel = false)
    }

    private fun removeGame(name: String) {
        File(romDir, name).delete()
        File(romDir, name.substringBeforeLast('.') + ".sav").delete()
        stateDir.listFiles()?.filter { it.name.startsWith("$name.") }?.forEach { it.delete() }
        if (name == romName) { romName = null; fastForward = false; controls.fastOn = false }
        if (prefs.getString("rom", null) == name) prefs.edit().remove("rom").apply()
        showHome()
        toast("Removed")
    }

    // ---------- ROMs ----------
    private fun pickRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, 1) } catch (e: Exception) { toast("No file picker available") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri? = data?.data
        if (req != 1 || res != RESULT_OK || uri == null) return
        Thread {
            val name = displayName(uri)
            val dest = File(romDir, name)
            try { contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { o -> i.copyTo(o, 1 shl 16) } } }
            catch (e: Exception) { runOnUiThread { toast("Could not read file") }; return@Thread }
            runOnUiThread { loadRom(dest.name) }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        var n: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i) }
        }
        return (n ?: "game.gba").replace(Regex("[^A-Za-z0-9._ -]"), "_")
    }

    private fun loadRom(name: String) {
        if (core.nativeLoadRom(File(romDir, name).absolutePath)) {
            romName = name; prefs.edit().putString("rom", name).apply()
            fastForward = false; controls.fastOn = false; core.nativeSetSpeed(1)
            hideHome()
            core.nativeSetPaused(false)
        } else {
            toast("Not a valid GBA ROM")
            if (homeOpen) home.refresh(listGames(), prefs.getString("rom", null), romName != null)
        }
    }

    // ---------- Menu ----------
    private fun sheet(title: String, subtitle: String?, items: List<SheetItem>, resumeOnCancel: Boolean = true) {
        dialogOpen = true
        val d = buildSheet(this, title, subtitle, items,
            onPick = { item -> dialogOpen = false; item.onClick() },
            onCancel = { dialogOpen = false; if (resumeOnCancel) resume() })
        d.show(); hideBars()
    }

    private fun showMenu() {
        if (dialogOpen || homeOpen) return
        controls.release(); core.nativeSetPaused(true)
        sheet("Menu", romName?.let { prettyName(it) }, listOf(
            SheetItem("Resume", style = STYLE_PRIMARY) { resume() },
            SheetItem("Save states") { showStates() },
            SheetItem("Fast-forward", if (fastForward) "ON" else "OFF") { toggleFast(); resume() },
            SheetItem("Reset") { romName?.let { n -> loadRom(n) }; resume() },
            SheetItem("Home") { showHome() },
            SheetItem("Open ROM") { pickRom() }
        ))
    }

    private fun toggleFast() {
        fastForward = !fastForward
        core.nativeSetSpeed(if (fastForward) 4 else 1)
        controls.fastOn = fastForward
    }

    // ---------- Save states (Quick Save (auto) + slots 0..7, each with a thumbnail) ----------
    private val slotKeys = listOf("q") + (0..7).map { "s$it" }

    private fun stateFile(key: String) = File(stateDir, "${romName ?: "game"}.$key.ss")
    private fun thumbFile(key: String) = File(stateDir, "${romName ?: "game"}.$key.png")
    private fun slotTitle(key: String) = if (key == "q") "QUICK SAVE (AUTO)" else "SLOT ${key.substring(1)}"

    /** Writes state + screenshot for [key]. Returns false when nothing could be saved. */
    private fun writeSlot(key: String): Boolean {
        if (romName == null) return false
        val data = core.nativeGetState() ?: return false
        try {
            stateFile(key).writeBytes(data)
            core.nativeGetFrame()?.let { px ->
                val bmp = Bitmap.createBitmap(px, 240, 160, Bitmap.Config.ARGB_8888)
                thumbFile(key).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
            }
        } catch (e: Exception) { return false }
        return true
    }

    private fun quickSave() { if (romName != null) writeSlot("q") }

    private fun slotInfos(): List<SlotInfo> = slotKeys.map { key ->
        val f = stateFile(key)
        if (f.exists()) {
            val bmp = thumbFile(key).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
            SlotInfo(key, slotTitle(key), f.lastModified(), bmp)
        } else SlotInfo(key, slotTitle(key), null, null)
    }

    private fun showStates() {
        if (romName == null) { toast("Load a game first"); resume(); return }
        statesOpen = true
        states.refresh(slotInfos())
        states.visibility = View.VISIBLE
    }

    private fun closeStates() { statesOpen = false; states.visibility = View.GONE; resume() }

    private fun slotTapped(key: String) {
        val f = stateFile(key)
        val exists = f.exists()
        val items = ArrayList<SheetItem>()
        items.add(SheetItem("Save here", style = if (exists) STYLE_NORMAL else STYLE_PRIMARY) {
            toast(if (writeSlot(key)) "Saved" else "Save failed")
            states.refresh(slotInfos())
        })
        if (exists) {
            items.add(SheetItem("Load", style = STYLE_PRIMARY) {
                if (core.nativeLoadState(f.readBytes())) { toast("Loaded"); closeStates() } else toast("Load failed")
            })
            items.add(SheetItem("Delete", style = STYLE_DANGER) {
                f.delete(); thumbFile(key).delete(); states.refresh(slotInfos())
            })
        }
        items.add(SheetItem("Cancel") { })
        val sub = if (exists) java.text.SimpleDateFormat("dd/MM/yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(f.lastModified())) else "Empty"
        sheet(slotTitle(key).lowercase().replaceFirstChar { it.uppercase() }, sub, items, resumeOnCancel = false)
    }

    private fun resume() { if (!dialogOpen && !homeOpen && !statesOpen) core.nativeSetPaused(false) }

    // ---------- Input ----------
    private fun sendKeys() = core.nativeSetKeys(touchMask or padMask)

    private fun mapKey(code: Int) = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Gba.UP; KeyEvent.KEYCODE_DPAD_DOWN -> Gba.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Gba.LEFT; KeyEvent.KEYCODE_DPAD_RIGHT -> Gba.RIGHT
        KeyEvent.KEYCODE_BUTTON_B -> Gba.A; KeyEvent.KEYCODE_BUTTON_A -> Gba.B   // Xbox-style layout
        KeyEvent.KEYCODE_BUTTON_L1 -> Gba.L; KeyEvent.KEYCODE_BUTTON_R1 -> Gba.R
        KeyEvent.KEYCODE_BUTTON_START -> Gba.START; KeyEvent.KEYCODE_BUTTON_SELECT -> Gba.SELECT
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_UP) { showMenu(); return true }
        val pad = e.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_DPAD) != 0
        val k = if (pad && !homeOpen) mapKey(e.keyCode) else -1
        if (k >= 0) {
            padMask = if (e.action == KeyEvent.ACTION_DOWN) padMask or Gba.bit(k) else padMask and Gba.bit(k).inv()
            sendKeys(); return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (!homeOpen && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X); val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            var m = padMask and (Gba.bit(Gba.LEFT) or Gba.bit(Gba.RIGHT) or Gba.bit(Gba.UP) or Gba.bit(Gba.DOWN)).inv()
            if (x < -0.5f) m = m or Gba.bit(Gba.LEFT); if (x > 0.5f) m = m or Gba.bit(Gba.RIGHT)
            if (y < -0.5f) m = m or Gba.bit(Gba.UP); if (y > 0.5f) m = m or Gba.bit(Gba.DOWN)
            padMask = m; sendKeys(); return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    @Deprecated("Back opens the menu / leaves the home screen")
    override fun onBackPressed() {
        if (statesOpen) { closeStates(); return }
        if (homeOpen) {
            if (romName != null) { hideHome(); resume() } else finish()   // game in progress: back returns to it
        } else showMenu()
    }

    // ---------- Lifecycle ----------
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) hideBars() }
    override fun onPause() { if (!homeOpen) quickSave(); controls.release(); core.nativeSetPaused(true); super.onPause() }
    override fun onResume() { super.onResume(); resume() }
    override fun onDestroy() { core.nativeShutdown(); super.onDestroy() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Places the game picture exactly where the GrLabs HTML launcher puts it (see Geo); controls draw over everything. */
class GameLayout(ctx: android.content.Context, private val game: View, private val ui: View) : ViewGroup(ctx) {
    private val dp = ctx.resources.displayMetrics.density
    init { setBackgroundColor(Color.BLACK); addView(game); addView(ui) }
    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws); val h = MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        val g = Geo.gameRect(w, h, dp)
        game.measure(MeasureSpec.makeMeasureSpec(g.width().toInt(), MeasureSpec.EXACTLY),
                     MeasureSpec.makeMeasureSpec(g.height().toInt(), MeasureSpec.EXACTLY))
        ui.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val g = Geo.gameRect(measuredWidth, measuredHeight, dp)
        game.layout(g.left.toInt(), g.top.toInt(), g.left.toInt() + game.measuredWidth, g.top.toInt() + game.measuredHeight)
        ui.layout(0, 0, measuredWidth, measuredHeight)
    }
}
