package com.gbaport.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.view.View.MeasureSpec
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val core = NativeCore()
    private lateinit var controls: ControlsView
    private val prefs by lazy { getSharedPreferences("gba", MODE_PRIVATE) }
    private val romDir by lazy { File(filesDir, "roms").apply { mkdirs() } }
    private val stateDir by lazy { File(filesDir, "states").apply { mkdirs() } }
    private var romName: String? = null
    private var touchMask = 0
    private var padMask = 0
    private var fastForward = false
    private var dialogOpen = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        core.nativeInit()

        val surface = SurfaceView(this)
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) = core.nativeSurfaceCreated(h.surface)
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) = core.nativeSurfaceDestroyed()
        })
        controls = ControlsView(this, { m -> touchMask = m; sendKeys() }, { showMenu() })
        setContentView(GameLayout(this, surface, controls))
        hideBars()

        val last = prefs.getString("rom", null)
        if (last != null && File(romDir, last).exists()) loadRom(last) else pickRom()
    }

    // ---------- ROMs ----------
    private fun pickRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, 1) } catch (e: Exception) { toast("No file picker available") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri? = data?.data
        if (req != 1 || res != RESULT_OK || uri == null) { if (romName == null) toast("Tap MENU \u2192 Open ROM"); return }
        Thread {
            val name = displayName(uri)
            val dest = File(romDir, name)
            try { contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { o -> i.copyTo(o, 1 shl 16) } } }
            catch (e: Exception) { runOnUiThread { toast("Could not read file") }; return@Thread }
            runOnUiThread { loadRom(dest.name) }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        var n: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i) }
        }
        return (n ?: "game.gba").replace(Regex("[^A-Za-z0-9._ -]"), "_")
    }

    private fun loadRom(name: String) {
        if (core.nativeLoadRom(File(romDir, name).absolutePath)) {
            romName = name; prefs.edit().putString("rom", name).apply()
            fastForward = false; core.nativeSetSpeed(1)
            core.nativeSetPaused(false)
        } else toast("Not a valid GBA ROM")
    }

    // ---------- Menu ----------
    private fun showMenu() {
        if (dialogOpen) return
        controls.release(); core.nativeSetPaused(true)
        val items = arrayOf("Resume", "Save state", "Load state", "Fast-forward: " + if (fastForward) "ON" else "OFF", "Reset", "Open ROM")
        dialog(items) { when (it) {
            0 -> resume()
            1 -> slotMenu(true)
            2 -> slotMenu(false)
            3 -> { fastForward = !fastForward; core.nativeSetSpeed(if (fastForward) 4 else 1); resume() }
            4 -> { romName?.let { n -> loadRom(n) }; resume() }
            5 -> pickRom()
        } }
    }

    private fun stateFile(slot: Int) = File(stateDir, "${romName ?: "game"}.$slot.ss")

    private fun slotMenu(save: Boolean) {
        if (romName == null) { toast("Load a game first"); resume(); return }
        val items = Array(3) { "Slot ${it + 1}" + if (stateFile(it + 1).exists()) "" else " (empty)" }
        dialog(items) { i ->
            val f = stateFile(i + 1)
            if (save) {
                val d = core.nativeGetState()
                if (d != null) { f.writeBytes(d); toast("Saved slot ${i + 1}") } else toast("Save failed")
            } else if (f.exists()) {
                toast(if (core.nativeLoadState(f.readBytes())) "Loaded slot ${i + 1}" else "Load failed")
            } else toast("Slot ${i + 1} is empty")
            resume()
        }
    }

    private fun dialog(items: Array<String>, pick: (Int) -> Unit) {
        dialogOpen = true
        AlertDialog.Builder(this).setItems(items) { _, i -> dialogOpen = false; pick(i) }
            .setOnCancelListener { dialogOpen = false; resume() }
            .show().also { hideBars() }
    }
    private fun resume() { if (!dialogOpen) core.nativeSetPaused(false) }

    // ---------- Input ----------
    private fun sendKeys() = core.nativeSetKeys(touchMask or padMask)

    private fun mapKey(code: Int) = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Gba.UP; KeyEvent.KEYCODE_DPAD_DOWN -> Gba.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Gba.LEFT; KeyEvent.KEYCODE_DPAD_RIGHT -> Gba.RIGHT
        KeyEvent.KEYCODE_BUTTON_B -> Gba.A; KeyEvent.KEYCODE_BUTTON_A -> Gba.B   // Xbox-style layout
        KeyEvent.KEYCODE_BUTTON_L1 -> Gba.L; KeyEvent.KEYCODE_BUTTON_R1 -> Gba.R
        KeyEvent.KEYCODE_BUTTON_START -> Gba.START; KeyEvent.KEYCODE_BUTTON_SELECT -> Gba.SELECT
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_UP) { showMenu(); return true }
        val pad = e.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_DPAD) != 0
        val k = if (pad) mapKey(e.keyCode) else -1
        if (k >= 0) {
            padMask = if (e.action == KeyEvent.ACTION_DOWN) padMask or Gba.bit(k) else padMask and Gba.bit(k).inv()
            sendKeys(); return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X); val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            var m = padMask and (Gba.bit(Gba.LEFT) or Gba.bit(Gba.RIGHT) or Gba.bit(Gba.UP) or Gba.bit(Gba.DOWN)).inv()
            if (x < -0.5f) m = m or Gba.bit(Gba.LEFT); if (x > 0.5f) m = m or Gba.bit(Gba.RIGHT)
            if (y < -0.5f) m = m or Gba.bit(Gba.UP); if (y > 0.5f) m = m or Gba.bit(Gba.DOWN)
            padMask = m; sendKeys(); return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    @Deprecated("Back opens the menu") override fun onBackPressed() = showMenu()

    // ---------- Lifecycle ----------
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) hideBars() }
    override fun onPause() { controls.release(); core.nativeSetPaused(true); super.onPause() }
    override fun onResume() { super.onResume(); if (!dialogOpen) core.nativeSetPaused(false) }
    override fun onDestroy() { core.nativeShutdown(); super.onDestroy() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Portrait: game in the top 3:2 area, controls below. Landscape: game fills the screen, controls overlay. */
class GameLayout(ctx: android.content.Context, private val game: View, private val ui: View) : ViewGroup(ctx) {
    init { setBackgroundColor(Color.BLACK); addView(game); addView(ui) }
    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws); val h = MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        val gh = if (h > w) w * 2 / 3 else h
        game.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(gh, MeasureSpec.EXACTLY))
        ui.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) {
        game.layout(0, 0, game.measuredWidth, game.measuredHeight)
        ui.layout(0, 0, measuredWidth, measuredHeight)
    }
}
