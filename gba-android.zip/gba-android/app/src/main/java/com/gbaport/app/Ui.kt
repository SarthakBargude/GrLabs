package com.gbaport.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/** Colours shared by the menu and the home screen (same palette as the GrLabs launcher). */
object Ui {
    val ACCENT = 0xFF7AA2FF.toInt()
    val ACCENT_HI = 0xFF9DB8FF.toInt()
    val CARD = 0xFF14141A.toInt()
    val CARD_HI = 0xFF1D1D26.toInt()
    val BORDER = 0xFF2E2E38.toInt()
    val TEXT = 0xFFF2F2F7.toInt()
    val MUTED = 0xFF9A9AA8.toInt()
    val DANGER = 0xFFFF6B6B.toInt()
    val BADGES = intArrayOf(
        0xFF7AA2FF.toInt(), 0xFF6EE7B7.toInt(), 0xFFF9A8D4.toInt(),
        0xFFFCD34D.toInt(), 0xFFC4B5FD.toInt(), 0xFFFDBA74.toInt())
}

fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun shape(color: Int, radius: Float, strokeColor: Int = 0, strokeWidth: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable = StateListDrawable().apply {
    addState(intArrayOf(android.R.attr.state_pressed), pressed)
    addState(intArrayOf(), normal)
}

fun label(ctx: Context, text: String, sp: Float, color: Int, bold: Boolean = false, spacing: Float = 0f): TextView =
    TextView(ctx).apply {
        this.text = text; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        letterSpacing = spacing
        includeFontPadding = false
    }

fun prettyName(file: String): String = file.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { file }

// =====================================================================================================
// Menu sheet
// =====================================================================================================

const val STYLE_NORMAL = 0
const val STYLE_PRIMARY = 1
const val STYLE_DANGER = 2

class SheetItem(val label: String, val detail: String? = null, val style: Int = STYLE_NORMAL, val onClick: () -> Unit)

/** Dark rounded card with a title and a list of tappable rows. Back / tapping outside calls [onCancel]. */
fun buildSheet(a: Activity, title: String, subtitle: String?, items: List<SheetItem>,
               onPick: (SheetItem) -> Unit, onCancel: () -> Unit): Dialog {
    val d = Dialog(a)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)

    val card = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Ui.CARD, a.dpi(22f).toFloat(), Ui.BORDER, a.dpi(1f))
        setPadding(a.dpi(10f), a.dpi(20f), a.dpi(10f), a.dpi(10f))
    }
    card.addView(label(a, title, 20f, Ui.TEXT, true).apply { setPadding(a.dpi(12f), 0, a.dpi(12f), 0) })
    if (subtitle != null) {
        card.addView(label(a, subtitle, 12.5f, Ui.MUTED).apply {
            setPadding(a.dpi(12f), a.dpi(6f), a.dpi(12f), 0)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
    }

    val list = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, a.dpi(14f), 0, 0)
    }
    for (item in items) list.addView(sheetRow(a, item) { d.dismiss(); onPick(item) })
    val scroll = ScrollView(a).apply { isVerticalScrollBarEnabled = false; addView(list) }
    card.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    d.setContentView(card)
    d.setOnCancelListener { onCancel() }
    d.window?.apply {
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        setDimAmount(0.7f)
        val w = minOf(a.resources.displayMetrics.widthPixels - a.dpi(32f), a.dpi(360f))
        setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    return d
}

private fun sheetRow(a: Activity, item: SheetItem, click: () -> Unit): View {
    val r = a.dpi(14f).toFloat()
    val primary = item.style == STYLE_PRIMARY
    val textColor = when (item.style) { STYLE_PRIMARY -> 0xFF0B0B0F.toInt(); STYLE_DANGER -> Ui.DANGER; else -> Ui.TEXT }
    val normal = shape(if (primary) Ui.ACCENT else Color.TRANSPARENT, r)
    val pressed = shape(if (primary) Ui.ACCENT_HI else 0x22FFFFFF, r)

    return LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(a.dpi(14f), 0, a.dpi(14f), 0)
        background = pressable(normal, pressed)
        isClickable = true
        setOnClickListener { click() }
        addView(label(a, item.label, 16f, textColor, primary || item.style == STYLE_DANGER),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        item.detail?.let { det ->
            addView(label(a, det, 13f, if (det == "ON") Ui.ACCENT else Ui.MUTED, true))
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dpi(52f)).apply {
            bottomMargin = a.dpi(4f)
        }
    }
}

// =====================================================================================================
// Home screen
// =====================================================================================================

class Game(val name: String, val size: Long)

/** Full-screen home: brand header, "continue" card, game library, add button. */
class HomeView(
    ctx: Context,
    private val onPlay: (String) -> Unit,
    private val onAdd: () -> Unit,
    private val onRemove: (String) -> Unit
) : FrameLayout(ctx) {

    private val content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; isFillViewport = true }
        sv.addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        addView(sv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        val p = context.dpi(20f)
        content.setPadding(p + insL, context.dpi(18f) + insT, p + insR, context.dpi(28f) + insB)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post {
            val lp = content.layoutParams as LayoutParams
            lp.width = minOf(w, context.dpi(620f)); lp.gravity = Gravity.CENTER_HORIZONTAL
            content.layoutParams = lp
        }
    }

    fun refresh(games: List<Game>, lastName: String?, running: Boolean) {
        val c = context
        content.removeAllViews()

        // ---- header: logo + brand on the left, add button on the right
        val header = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(c).apply {
            setImageResource(R.drawable.grlabs_logo); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(22f)))
        header.addView(label(c, "GrLabs", 13f, Color.WHITE, true, 0.14f).apply { setPadding(c.dpi(8f), 0, 0, 0) })
        header.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(pillButton(c, "+  Add game", 13f, 38f) { onAdd() })
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- title
        content.addView(label(c, "Games", 32f, Ui.TEXT, true), topMargin(c, 30f))
        val count = if (games.isEmpty()) "Nothing here yet" else "${games.size} in your library"
        content.addView(label(c, count, 14f, Ui.MUTED), topMargin(c, 6f))

        if (games.isEmpty()) { emptyState(c); return }

        // ---- continue card
        val last = games.firstOrNull { it.name == lastName }
        if (last != null) content.addView(continueCard(c, last, running), topMargin(c, 24f))

        // ---- library
        content.addView(label(c, "LIBRARY", 11f, Ui.MUTED, true, 0.16f), topMargin(c, 28f))
        for (g in games) content.addView(gameRow(c, g), topMargin(c, 10f))
        content.addView(label(c, "Long-press a game to remove it", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER },
            topMargin(c, 18f))
    }

    private fun topMargin(c: Context, dp: Float) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = c.dpi(dp) }

    private fun pillButton(c: Context, text: String, sp: Float, heightDp: Float, click: () -> Unit): View =
        TextView(c).apply {
            this.text = text; textSize = sp; setTextColor(0xFF0B0B0F.toInt()); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; includeFontPadding = false
            setPadding(c.dpi(18f), 0, c.dpi(18f), 0)
            val r = c.dpi(heightDp / 2f).toFloat()
            background = pressable(shape(Ui.ACCENT, r), shape(Ui.ACCENT_HI, r))
            isClickable = true; setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(heightDp))
        }

    private fun continueCard(c: Context, g: Game, running: Boolean): View {
        val r = c.dpi(22f).toFloat()
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dpi(20f), c.dpi(20f), c.dpi(16f), c.dpi(20f))
            background = pressable(shape(Ui.CARD_HI, r, Ui.BORDER, c.dpi(1f)), shape(0xFF262632.toInt(), r, Ui.BORDER, c.dpi(1f)))
            isClickable = true; setOnClickListener { onPlay(g.name) }
        }
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(c, if (running) "PLAYING NOW" else "CONTINUE", 11f, Ui.ACCENT, true, 0.16f))
        col.addView(label(c, prettyName(g.name), 21f, Ui.TEXT, true).apply {
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        }, topMargin(c, 8f))
        col.addView(label(c, if (running) "Jump back in" else "Pick up where you left off", 13f, Ui.MUTED), topMargin(c, 6f))
        card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(TextView(c).apply {
            text = if (running) "Resume" else "Play"; textSize = 14f; setTextColor(0xFF0B0B0F.toInt())
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; includeFontPadding = false
            setPadding(c.dpi(20f), 0, c.dpi(20f), 0)
            background = shape(Ui.ACCENT, c.dpi(22f).toFloat())
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(44f)))
        return card
    }

    private fun gameRow(c: Context, g: Game): View {
        val r = c.dpi(16f).toFloat()
        val tint = Ui.BADGES[(g.name.hashCode() and 0x7FFFFFFF) % Ui.BADGES.size]
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dpi(12f), c.dpi(12f), c.dpi(16f), c.dpi(12f))
            background = pressable(shape(Ui.CARD, r, Ui.BORDER, c.dpi(1f)), shape(Ui.CARD_HI, r, Ui.BORDER, c.dpi(1f)))
            isClickable = true
            setOnClickListener { onPlay(g.name) }
            setOnLongClickListener { onRemove(g.name); true }
        }
        val letter = prettyName(g.name).firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "G"
        row.addView(TextView(c).apply {
            text = letter; textSize = 18f; setTextColor(tint); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; includeFontPadding = false
            background = shape((tint and 0x00FFFFFF) or 0x33000000, c.dpi(12f).toFloat())
        }, LinearLayout.LayoutParams(c.dpi(46f), c.dpi(46f)))
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(c.dpi(14f), 0, 0, 0) }
        col.addView(label(c, prettyName(g.name), 15.5f, Ui.TEXT, true).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(label(c, String.format(Locale.US, "%.1f MB", g.size / 1048576.0), 12.5f, Ui.MUTED), topMargin(c, 5f))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(label(c, "›", 24f, Ui.MUTED))
        return row
    }

    private fun emptyState(c: Context) {
        val r = c.dpi(22f).toFloat()
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(c.dpi(24f), c.dpi(32f), c.dpi(24f), c.dpi(32f))
            background = shape(Ui.CARD, r, Ui.BORDER, c.dpi(1f))
        }
        card.addView(label(c, "No games yet", 19f, Ui.TEXT, true))
        card.addView(label(c, "Add a .gba file from your device and it will show up here.", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }, topMargin(c, 10f))
        card.addView(pillButton(c, "Add game", 15f, 46f) { onAdd() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(46f)).apply { topMargin = c.dpi(24f) })
        content.addView(card, topMargin(c, 32f))
    }
}
